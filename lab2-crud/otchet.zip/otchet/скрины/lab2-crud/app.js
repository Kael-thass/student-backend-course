const express = require('express');
const app = express();
const port = 3000;

// Middleware для парсинга JSON
app.use(express.json());

// Middleware для логирования
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

//вариант 7
let cities = [
    { id: 1, name: 'Москва', population: 13000000, country: 'Россия', area: 2561 },
    { id: 2, name: 'Санкт-Петербург', population: 5600000, country: 'Россия', area: 1439 },
    { id: 3, name: 'Нью-Йорк', population: 8400000, country: 'США', area: 783 }
];
let nextId = 4;

//GET /items (Список + Поиск + Сортировка + Пагинация)
app.get('/items', (req, res) => {
    let result = [...cities];

    //поиск
    if (req.query.search) {
        const searchLower = req.query.search.toLowerCase();
        result = result.filter(c => c.name.toLowerCase().includes(searchLower));
    }

    //сортировка
    if (req.query.sort) {
        const field = req.query.sort;
        const order = req.query.order === 'desc' ? -1 : 1;
        result.sort((a, b) => {
            if (a[field] < b[field]) return -1 * order;
            if (a[field] > b[field]) return 1 * order;
            return 0;
        });
    }

    //пагинация
    if (req.query.page && req.query.limit) {
        const page = parseInt(req.query.page);
        const limit = parseInt(req.query.limit);
        const start = (page - 1) * limit;
        result = result.slice(start, start + limit);
    }

    res.json({ count: result.length, items: result });
});

//GET /items/:id
app.get('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const city = cities.find(c => c.id === id);
    if (!city) {
        return res.status(404).json({ error: 'Город не найден' });
    }
    res.json(city);
});

//POST /items (Создание + Валидация)
app.post('/items', (req, res) => {
    const { name, population, country, area } = req.body;

    // Валидация
    if (!name) {
        return res.status(400).json({ error: 'Поле name обязательно' });
    }
    if (population !== undefined && typeof population !== 'number') {
        return res.status(400).json({ error: 'Поле population должно быть числом' });
    }
    if (area !== undefined && typeof area !== 'number') {
        return res.status(400).json({ error: 'Поле area должно быть числом' });
    }

    const newCity = {
        id: nextId++,
        name: name,
        population: population || 0,
        country: country || 'Неизвестно',
        area: area || 0
    };

    cities.push(newCity);
    res.status(201).json(newCity);
});

//PUT /items/:id (Полное обновление)
app.put('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = cities.findIndex(c => c.id === id);

    if (index === -1) {
        return res.status(404).json({ error: 'Город не найден' });
    }

    const { name, population, country, area } = req.body;

    if (!name) {
        return res.status(400).json({ error: 'Поле name обязательно' });
    }

    cities[index] = {
        id: id,
        name: name,
        population: population !== undefined ? population : cities[index].population,
        country: country !== undefined ? country : cities[index].country,
        area: area !== undefined ? area : cities[index].area
    };

    res.json(cities[index]);
});

//DELETE /items/:id (Удаление)
app.delete('/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = cities.findIndex(c => c.id === id);

    if (index === -1) {
        return res.status(404).json({ error: 'Город не найден' });
    }

    cities.splice(index, 1);

    //204 No Content
    res.status(204).send();
});

//404
app.use((req, res) => {
    res.status(404).json({ error: 'Маршрут не найден' });
});

//запуск
app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});